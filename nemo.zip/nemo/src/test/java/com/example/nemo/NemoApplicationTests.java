package com.example.nemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
